from .import views
from django.urls import path
app_name='shop'

urlpatterns = [
    path('',views.Home,name='home'),
    path('<slug:c_slug>/',views.Home,name='product_by_category'),
]
